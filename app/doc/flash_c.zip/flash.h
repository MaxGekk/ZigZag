/*
+-------------------------------------------------------------------------------+
: 			copyright (c) Jean Randhahn  				:
+-------------------------------------------------------------------------------+
: Project         : CANeye - Uni Rostock                                        :
: Compiler        : IAR workbench GUI 2.31E / target descriptor v1.26A/WIN      :
+-------------------------------------------------------------------------------+
:                                                                               :
: class		  : flash                                                       :
: File name       : flash.h                                                     :
: Target hardware : MSP430F148/9                                                :
:                                                                               :
: File Editor     : J. Randhahn                                                 :
: Created         : 06.08.2002                                                  :
:                                                                               :
: Description     :                                                             :
:                                                                  	        :
:                                                                            	:
:		                                                                :
:                                                                               :
+-------------------------------------------------------------------------------+
:                                                                               :
: Modification history:                                                         :
:                                                                               :
:                                                                               :
+-------------------------------------------------------------------------------+
*/
#ifndef __FLASH_H__
#define __FLASH_H__

#ifdef  __FLASH__
/*::::::::::::::::::::::::: START OF LOCAL PART ::::::::::::::::::::::::::::::::*/
/*----------------------- LOCAL INCLUDES ---------------------------------------*/
#include <msp430x14x.h>
#include "type.h"

/*----------------------- LOCAL DEFINITIONS ------------------------------------*/

/*----------------------- LOCAL FUNCTION DECLARATIONS --------------------------*/
       void          flash_eraseFLASH(BYTE *seg);
       void          flash_writeWord(WORD *dst, WORD value);
       void          flash_writeByte(BYTE *dst, BYTE value);
       void          flash_saveInfoFlash(BYTE *container, BYTE *flashPage);
       void          flash_changeInfo(BYTE* containerBase, BYTE *pointer, BYTE value);
       void          flash_updateInfo(BYTE *container, BYTE *flashPageBase);

/*----------------------- LOCAL CONSTANTS AND VARIABLES ------------------------*/

/*----------------------- PUBLIC VARIABLES WITH INITIALISATION -----------------*/


/*::::::::::::::::::::::::: END OF LOCAL PART ::::::::::::::::::::::::::::::::::*/

#else
/*----------------------- PUBLIC VARIBALES INITIALIZED LOCALLY -----------------*/
#endif

/*-------------------- PUBLIC DEFINITIONS --------------------------------------*/

/*-------------------- PUBLIC CONSTANTS AND VARIABLES --------------------------*/

/*-------------------- PUBLIC FUNCTION DECLARATIONS ----------------------------*/
extern void          flash_eraseFLASH(BYTE *seg);
extern void          flash_writeWord(WORD *dst, WORD value);
extern void          flash_writeByte(BYTE *dst, BYTE value);
extern void          flash_saveInfoFlash(BYTE *container, BYTE *flashPage);
extern void          flash_changeInfo(BYTE* containerBase, BYTE *pointer, BYTE value);
extern void          flash_updateInfo(BYTE *container, BYTE *flashPageBase);
#endif