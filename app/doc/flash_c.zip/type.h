//type.h
/* START type definitions for convinience with microcontrollers ****************************/
typedef unsigned char    BYTE;            /* 8 bits */
typedef unsigned short   WORD;           /* 16 bits */
typedef unsigned long    LONGWORD;       /* 32 bits */

/* for dividing a WORD into two BYTEs */
typedef  union   _WORD_BYTE
          { WORD   w;
            BYTE   b[2];
          } WORD_BYTE;
