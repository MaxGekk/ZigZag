//flash.c
#define  __FLASH__
#define  __HW_v_2_1__
#include "flash.h"

/*************************************************************************************************
*     This section contains all FLASH memory relevant functions:                                 *
*       writeByte                                                                                *
*       writeWord                                                                                *
*       eraseFLASH                                                                               *
*       saveInfoFlash                                                                            *
*       changeInfo                                                                               *
*       updateInfo                                                                               *
*                                                                                                *
*************************************************************************************************/
/*************************************************************************************************
Function :        flash_writeFLASH
Parameter :       *dst  :  address within the FLASH page
                  value :  BYTE that has to be written to FLASH
Date :            08.09.2001 / 17.11.2002 / 22.11.2002
Description :     this function writes a byte to an address in FLASH memory
                  warning: in FLASH only zeros can be written. if a bit value needs to be set to
                  one from zero, the whole page has to be erased, thus setting all bits to one.
                  then the value can be written correctly. this function does not perform the
                  necessary FLASH page erase.
*************************************************************************************************/
void flash_writeByte(BYTE *dst, BYTE value)
{
  FCTL2 = FWKEY | FSSEL0 | 20;        //clock source is MCLK, divisor is 20
  do
  {
    _NOP();
  } while(FCTL3 & 0x0001);            // wait for BUSY to reset
  FCTL3 = FWKEY;                      // reset the LOCK bit to enable program/erase
  FCTL1 = FWKEY | WRT;                // set WRT for single acces

  *dst = value;                       // do the write as a byte

  return;
}

/*************************************************************************************************
Function :        flash_writeWord
Parameter :       *dst  :  address within the FLASH page
                  value :  BYTE that has to be written to FLASH
Date :            22.11.2002
Description :     this function writes a word to an address in FLASH memory
                  warning: in FLASH only zeros can be written. if a bit value needs to be set to
                  one from zero, the whole page has to be erased, thus setting all bits to one.
                  then the value can be written correctly. this function does not perform the
                  necessary FLASH page erase.
*************************************************************************************************/
void flash_writeWord(WORD *dst, WORD value)
{
  FCTL2 = FWKEY | FSSEL0 | 20;        //clock source is MCLK, divisor is 20
  do
  {
    _NOP();
  } while(FCTL3 & 0x0001);            // wait for BUSY to reset
  FCTL3 = FWKEY;                      // reset the LOCK bit to enable program/erase
  FCTL1 = FWKEY | WRT;                // set WRT for single acces

  *dst = value;                       // do the write as a word

  return;
}

/*************************************************************************************************
Function :        flash_eraseFLASH
Parameter :       *seg  :  any address within the FLASH page that is to be erased
Date :            08.09.2001 / 19.11.2002
Description :     this function erases a FLASH page
*************************************************************************************************/
void flash_eraseFLASH(BYTE *seg)
{
  FCTL2 = FWKEY | FSSEL0 | 20;        //clock source is MCLK, divisor is 20
  do
  {
    _NOP();
  } while(FCTL3 & 0x0001);            // wait for BUSY to reset
  FCTL3 = FWKEY;                      // reset the LOCK bit to enable program/erase
  FCTL1 = FWKEY | ERASE;              // set single segment erase function

  *seg = 0xFF;                        // do a dummy write to start erase

  FCTL3 = FWKEY | LOCK;               // lock the flash again

  return;
}

/*************************************************************************************************
Function :        flash_saveInfoFlash
Parameter :       *container : pointer to updated copy of data in RAM
                  *flashPageBase : pointer to start of destination flash segment
Date :            11.09.2002 / 26.11.2002
Description :     saves info flash page 0 to RAM (!!! works only for INFO flash access !!!)
*************************************************************************************************/
void flash_saveInfoFlash(BYTE *container, BYTE *flashPageBase)
{
  BYTE i;

  flashPageBase = (BYTE*)((WORD)(flashPageBase) & 0xFF80);   // wrap around for flash page base address

  for(i=0;i<128;i++)
  {
    container[i] = *flashPage++;
  }
}

/*************************************************************************************************
Function :        flash_changeInfo
Parameter :       *container : pointer to updated copy of data in RAM
                  *pointer   : original pointer to variable that has to be updated
                  value      : new value for variable
Date :            11.09.2002 / 26.11.2002
Description :     chages a word in the info flash 0 data (in RAM)
*************************************************************************************************/
void flash_changeInfo(BYTE* containerBase, BYTE *pointer, BYTE value)
{
  // pointer points into flash page to variable that is supposed to be changed
  // subtract flash page offset (0x1000) and add scratch pad offset
  pointer = (BYTE*)(((WORD)(pointer) & 0x7F) + (WORD)(containerBase));
  *pointer = value;
}

/*************************************************************************************************
Function :        flash_update
Parameter :       *container : pointer to updated copy of data in RAM
                  *flashPageBase : pointer to start of destination flash segment
Date :            11.09.2002 / 26.11.2002
Description :     erases the flash page and writes the values from the RAM save area to flash
                  (!!! works only in INFO flash !!!)
*************************************************************************************************/
void flash_updateInfo(BYTE *container, BYTE *flashPageBase)
{
  // assumes prior saving and changing of flash data
  BYTE i;

  flashPageBase = (BYTE*)((WORD)(flashPageBase) & 0xFF80);   // wrap around for flash page base address

  _DINT();
  flash_eraseFLASH(flashPageBase);

  for(i=0;i<128;i++)
  {
    flash_writeByte(flashPageBase++,*(container++));
  }
  _EINT();
}